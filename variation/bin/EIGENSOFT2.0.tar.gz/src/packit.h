int packmode = NO ;  
unsigned char *packgenos = NULL ;
int packlen = 0 ;
int rlen = -1 ;
int rdismode = NO ;
unsigned char *packepath ; 

