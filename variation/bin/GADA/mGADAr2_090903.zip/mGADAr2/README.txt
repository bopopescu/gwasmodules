% GADA -- Genome Alteration Detection Analysis
%
% testFitGadaModel.m contains an example on how to fit the model. 
%
% Contents.m summarizes the contents of the toolbox. 
%
% MakeMex.m makes the Mex libraries necessary to run GADA.
%
%


