
// check which of these i need. riply 2000 email seems to be out of data

//int main(int argc, char *argv[]);


#include <R.h>
#include <Rdefines.h>
#include <Rinternals.h>

SEXP rint_flmm(SEXP pexplan_sexp, SEXP presp_sexp, SEXP pn_sexp, SEXP pp_sexp, SEXP pcovar_sexp, SEXP pp_covar_sexp, SEXP pKin_sexp, SEXP nu_naught_sexp, SEXP gamma_naught_sexp);
