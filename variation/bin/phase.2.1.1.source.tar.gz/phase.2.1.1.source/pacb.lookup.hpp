#ifndef PACB_H
#define PACB_H

double correction(int, int, double);
double derivcorrection(int, int, double);

#endif
