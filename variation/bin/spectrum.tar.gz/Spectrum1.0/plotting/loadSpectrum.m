function [indfreq, ancfreqT, rr] = loadSpectrum( fname, I ); 

fp = fopen( fname, 'r' );

if ( fp < 0 )
  fprintf( 'file error: %s\n', fname );
  indfreq = [];
  rr = [];
  return;
end

%%%%%%%%%%% individual frequency %%%%%%%%%%%%
tmp = fgetl( fp ); 
while( ~feof(fp) & isempty( findstr( tmp, '[Individual Spectrum]' )) == 1 )
	tmp = fgetl(fp );
end
clear indfreq;
for ii=1:I
	line = fgetl( fp );
	ik = sscanf( line, '%f ');
	if ( ii == 1 )
	  K = length(ik);
	  indfreq = zeros( I, K );
	end
	indfreq(ii,:) = ik';
end

%%%%%%%%%%% ancestor frequency %%%%%%%%%%%%
while( ~feof(fp) & isempty( findstr( tmp, '[Ancestor Frequency]' )) == 1 )
	tmp = fgetl(fp );
end
clear ancfreq;
for kk=1:K
	line = fgetl( fp );
	ik = sscanf( line, '%f ');
    if ( kk == 1 )
	  T = length(ik);
	  ancfreq = zeros( K, T );
	end
	ancfreqT(kk,:) = ik';
end

%%%%%%%%%%% recombination rate %%%%%%%%%%%%
while( isempty( findstr( tmp, '[rec]' )) == 1 )
	tmp = fgetl(fp );
end
line = fgetl(fp);
rr = sscanf( line, '%f');
fclose(fp);
