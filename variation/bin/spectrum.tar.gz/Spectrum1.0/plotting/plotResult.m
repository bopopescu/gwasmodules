%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% plotResult;
%% *** plot Spectrum result and save pdf files
%% - fname: outfilename from Spectrum
%% - lfile: filename for positions of each SNP 
%%      e.g. file content: [ 125400 126403 137089 ... ]
%% - pfile: filename for population labels for each individual 
%%      e.g. file content: [ 'CEU', 'CEU', 'YRI', ..., 'HCB'];
%% - outputheader: prefix for output filename
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%%%%%%%  Edit %%%%%%%%%%%%%%%%%%
fname = 'example.out';
lfile = 'position.txt';
pfile = 'poplabel.txt';
outputheader = 'example';
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%% load information %%%
poplabel = textread( pfile, '%s\n');
loci = load( lfile );

I = length( poplabel );
%%% load spectrum result %%%%%%
[indfreq, ancfreq, rec] = loadSpectrum( fname, I );

%%%%%% 1. population structure %%%%%%%%%%%%%
outname = strcat( outputheader, '_str.pdf' );
showPopStr( indfreq, poplabel, outname );

%%%%%% 2. ancestral structure %%%%%%%%%%%%%
outname = strcat( outputheader, '_anc.pdf' );
showAncStr( ancfreq, loci, outname );

%%%%%% 3. recomination rate %%%%%%%%%%%%%
outname = strcat( outputheader, '_rec.pdf' );
showRec( rec, loci, outname );

