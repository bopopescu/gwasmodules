Edit plotResult.m with appropriate filenames for Spectrum output, population label and loci positions, 
and a prefix for output. 

e.g.

fname = 'example.out';
lfile = 'position.txt';
pfile = 'poplabel.txt';
outputheader = 'example';
