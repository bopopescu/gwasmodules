function showAncStr( ancfreq, loci, outname );
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%    plot ancestor frequencies along chromosome
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

[K,T] = size( ancfreq );

%%%%%% plot figure %%%%%%
figure1 = figure('PaperOrientation','landscape');
axes1 = axes(...
  'FontSize',16,...
  'Parent',figure1);
hold(axes1,'all');

plot( loci, ancfreq', 'LineWidth', 2 );
for i=1:K
    leg{i} = sprintf('A%d', i) ;
end
xlabel( 'Position');
ylabel( 'Founder Frequency');
xlim( [loci(1),loci(end)] );
box on;
legend(axes1,leg,'Location','EastOutside');

print( outname, '-dpdf' );
