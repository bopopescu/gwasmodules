function showPopStr( indfreq, poplabel, outname );
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%    plot population structure from individual frequencies 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if ( isempty( indfreq ) )
  mat = [];
  K = -1;
  color = [];
  strPop = [];
  return;
end

[I, K] = size( indfreq );

%%% get population frequency and sort ind freq %%%
popsum = sum(indfreq);
popfr = popsum / sum(popsum);
[popfr, IA] = sort( popfr, 'descend' );
freq = indfreq(:, IA);

%%%%% sort individual order by population label %%%%%
[pp, ord] = sort( poplabel );
freq = freq( ord, : );
poplabel = pp;

hh = ceil(I*0.2); 
dc = 1/(K-1);

color = 0:dc:1;
cs = cumsum( popfr );
color = ( cs - popfr(1) )/(1-popfr(1));

%%% output matrix %%%
mat = zeros( hh, I );
for ii=1:I
    ra = zeros( 1, K);
    ra(1) = freq(ii, 1);
    for kk=2:K
        ra(kk) = ra(kk-1) + freq(ii, kk);
    end
    ra = ra * hh;
    ie = floor(ra); ie(end) = hh;
    is = [1 ie(1:end-1)+1];
    for kk=1:K
        mat(is(kk):ie(kk), ii) = color(kk);
    end
end
    
%%%%%% pop label %%%%%
id = 1;
veclabel{id} = pp{1};
bdr = [];
for ii=2:I
    if ( isequal( poplabel{ii}, poplabel{ii-1} ) == 0 )
        id = id+1;
        bdr = [bdr ii-1];
        veclabel{id} = poplabel{ii};
    end
end

nBdry = length(bdr);
xx = zeros(1, nBdry+1);
xx(1) = bdr(1)/2;
for bb=2:nBdry
    xx(bb) = (bdr(bb)+bdr(bb-1))/2;
end
xx(end) = (bdr(nBdry)+I)/2;

%%%%%% plot figure %%%%%%
figure1 = figure('PaperOrientation','landscape' );
axes1 = axes(...
  'FontSize',16,...
  'Layer','top',...
  'XTick',xx,...
  'XTickLabel',veclabel,...
  'YTick', [], ...
  'YDir','reverse',...
  'Parent',figure1);
hold(axes1,'all');
 
imagesc( mat, 'Parent', axes1 ); axis image; 
hold on;
for bb=1:nBdry
     plot( [bdr(bb)+0.5, bdr(bb)+0.5], [-0.5, size(mat,1)+0.5], 'k-' );
end
hold off;

print( outname, '-dpdf' );
