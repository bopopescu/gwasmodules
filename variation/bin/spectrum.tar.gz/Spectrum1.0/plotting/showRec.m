function showRec( rec, loci, outname );
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%    plot ancestor frequencies along chromosome
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

T = size(loci);

%%%%%% plot figure %%%%%%
figure1 = figure;
axes1 = axes(...
  'FontSize',16,...
  'Parent',figure1);
hold(axes1,'all');

if ( size( rec, 1 ) > 1 )
    rec = rec';
end
if ( size( loci, 1 ) > 1 )
    loci = loci';
end

xx = repmat( loci(2:end-1), 2, 1 );
xvec = [ loci(1), reshape( xx, 1, prod( size(xx) )), loci(end) ];
rr = repmat( rec, 2, 1 );
rvec = reshape( rr, 1, prod(size(rr)) );
plot( xvec, rvec );
xlabel( 'Position');
ylabel( 'Recombination rate');
xlim( [xx(1), xx(end)] );
box on;

print( outname, '-dpdf' );
